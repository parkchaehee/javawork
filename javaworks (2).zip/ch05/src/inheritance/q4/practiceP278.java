package inheritance.q4;



public class practiceP278 {

	public String name;
	public String grade;
	
	public void Employee(String name) {//void 없음
		this.name = name;   //;
	}

}

