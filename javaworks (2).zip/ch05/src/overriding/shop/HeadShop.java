package overriding.shop;

public class HeadShop {
	
	//public HeadShop() {}
	
	public void 된장찌개() {
		System.out.println("된장찌개: 7,000원");
	}
	public void 김치찌개() {
		System.out.println("김치찌개: 7,500원");
	}
	public void 비빔밥() {
		System.out.println("김치찌개: 8,000원");
	}
	
	
	

}
