package polymorphism.fruits;

public class Peach extends Fruit{
	
	public Peach() {
		name = "복숭아";
		weight = "900g";
		price = 10000;
	}

}
