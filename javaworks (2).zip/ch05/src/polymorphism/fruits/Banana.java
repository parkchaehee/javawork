package polymorphism.fruits;

public class Banana extends Fruit {
	
	public Banana() {
		name = "바나나";
		weight = "600g";
		price = 4000;
	}

}
