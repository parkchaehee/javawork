package protectedex.pack2;

public class C {
	
	public void method() {
		//A a = new A();  //A를 사용할수없음-(protected다른패키지라안됨)
		
	}

}
