package classes;

//계산기 자료형 정의
public class Calculator {
	
	//public Calculator(){}//생략되어있음
	
	//메서드 정의 - 더하기, 빼기, 곱하기, 나누기
	public int add(int n1, int n2) { ///add
		return n1 + n2;
	}
	public int sub(int n1, int n2) { ///sub
		return n1 - n2;
	}
	public int mul(int n1, int n2) { ///mul
		return n1 * n2;
	}
	public int div(int n1, int n2) { ///div
		return n1 / n2;
	}
	

}
