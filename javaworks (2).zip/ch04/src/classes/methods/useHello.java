package classes.methods;

public class useHello {

	public static void main(String[] args) {
		// Hello 클래스 사용
		Hello say = new Hello();
		say.sayHello();   //호출(콜)
		say.sayHello(" Elsa");
		say.sayHello(" 장그래");
		

	}

}
