package array2d;

public class Array2dApt {

	public static void main(String[] args) {
		// 아파트 세대 구현하기
		// 5층, 한층당 - 3세대
		// 3층 - 1세대
		int[][] household = new int[5][3];
		household[2] = new int[1];
		
		System.out.printf("5층 %d세대\n", household[4].length);//0행의 열(길이)
		System.out.printf("4층 %d세대\n", household[3].length);//0행의 열(길이)
		System.out.printf("3층 %d세대\n", household[2].length);//0행의 열(길이)
		System.out.printf("2층 %d세대\n", household[1].length);//0행의 열(길이)
		System.out.printf("1층 %d세대\n", household[0].length);//0행의 열(길이)

	}

}
