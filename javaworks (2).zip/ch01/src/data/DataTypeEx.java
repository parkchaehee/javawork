package data;

public class DataTypeEx {

	public static void main(String[] args) {
		// int, long의 사용
		//int형의 크기 - 4byte(32bit) -21*21억
		//long형 - 8byte(64bit)
		
		int num1 = 1234567890;//12억
		long num2 = 12345678900L;
		
		System.out.println(num1);
		System.out.println(num2);
		

	}

}
