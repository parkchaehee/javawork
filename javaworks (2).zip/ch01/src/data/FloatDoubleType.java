package data;

public class FloatDoubleType {

	public static void main(String[] args) {
		// 실수 자료형
		float fNum = 1.2345678f;//소수점이하 6자리까지 출력
		double dNum = 1.2345678901234567;//소수점이하 16자리까지 출력
		
		System.out.println(fNum);
		System.out.println(dNum);

	}

}
