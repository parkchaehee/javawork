package hello;


//파일 이름의 첫글자는 대문자로 함
//표기법(낙타-카멜표기) : 단어가 합성될때도 첫글자는 대문자로 함
public class HelloWorld {

	//main() 함수 필요 : 메모리(주기억장치)에서 실행/c드라이브 보조기억장치
	public static void main(String[] args) {
		// 한줄 주석 - 문자를 출력하는 프로그램 만들기
		System.out.println("Hello~ Java");
		System.out.println("안녕~ 자바");
		
		//자기소개
		System.out.println("이름-박채희");
		System.out.println("주소-인천 계양구 123");
		

	}

}
