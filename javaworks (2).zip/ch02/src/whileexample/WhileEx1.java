package whileexample;

public class WhileEx1 {

	public static void main(String[] args) {
		// while 반복문
		// 초기값, 종료 조건, 증감값(1증가, 1감소)
		
		int i = 0;                     //1.초기값
		
		while(i < 10) { //while(true)  //2.종료조건
			//i = i + 1;
			i++;                       //3.증감값
			System.out.println(i); //1,2,3....10
		}
		


		

	}

}
