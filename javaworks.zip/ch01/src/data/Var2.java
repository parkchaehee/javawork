package data;

public class Var2 {

	public static void main(String[] args) {
		// 1inch는 2.54cm입니다.
		// 실수형 (float, double)
		//double inchTocm = 2.54;
		float inchTocm = 2.54f; //float형은 값뒤에 f나 F를 붙임
		System.out.println("1inch는" + inchTocm + "입니다.");

	}

}
